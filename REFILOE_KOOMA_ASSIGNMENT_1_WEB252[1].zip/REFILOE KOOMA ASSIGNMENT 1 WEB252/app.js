const http = require("http"); 
const host = 'localhost';
const port = 8000; 

const requestListener = function (request , respond ) 
{ 	
    respond.setHeader("Content-Type", "text/html"); 
    respond.writeHead(200); 
	respond.end(`<html><body><h1> HELLO GOOD WORLD </h1></body></html>`); 
}; 

const server = http.createServer(requestListener);
 server.listen(port, host, () => { 		
    console.log(`HELLO GOOD WORLD on http://${host}:${port}`); 
}); 



